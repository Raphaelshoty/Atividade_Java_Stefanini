package locadora;

public class Carro {
	
	public Carro(String modelo) {
		super();
		this.modelo = modelo;
	}

	public Carro(){
		
	}
	
	private String modelo;

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	

}
