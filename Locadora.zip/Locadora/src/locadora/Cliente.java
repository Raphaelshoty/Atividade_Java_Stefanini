package locadora;

import java.util.Date;


public class Cliente {
	
	private int qtdPassageiros;
	private boolean premium;
	private Date entrada;
	private Date saida;
	
	public Cliente() {
		
	}
	
	public boolean isPremium() {
		return premium;
	}

	public void setPremium(boolean premium) {
		this.premium = premium;
	}

	public Date getEntrada() {
		return entrada;
	}

	public void setEntrada(Date entrada) {
		this.entrada = entrada;
	}

	public Date getSaida() {
		return saida;
	}

	public void setSaida(Date saida) {
		this.saida = saida;
	}

	

	public int getQtdPassageiros() {
		return qtdPassageiros;
	}
	
	public void setQtdPassageiros(int qtdPassageiros) {
		this.qtdPassageiros = qtdPassageiros;
	}
	
	public boolean isVip() {
		return premium;
	}
	
	public void setVip(boolean vip) {
		this.premium = vip;
	}
	
	
	
	
	

}
