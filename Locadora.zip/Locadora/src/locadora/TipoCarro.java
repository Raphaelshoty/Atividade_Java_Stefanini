package locadora;

public enum TipoCarro {

		SUV("SUV"), ESPORTIVO("ESPORTIVO"), COMPACTO("COMPACTO");
	
		private String tipoCarro;
		
		TipoCarro(String tipo) {
			this.setTipoCarro(tipo);
		}
		
		public String getTipoCarro() {
			return tipoCarro;
		}
		public void setTipoCarro(String tipoCarro) {
			this.tipoCarro = tipoCarro;
		}
	
}
