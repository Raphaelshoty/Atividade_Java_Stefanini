package locadora;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;



public class LocadoraMain {
	

	public static void main(String[] args) throws ParseException, IOException {
		
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		
		// criando os objetos Carro 
		Carro chevrolet_corsa = new Carro("Corsa");
		Carro fiat_freemont = new Carro("Freemont");
		Carro lamborgini_miura = new Carro("Miura");
		
		// armazenando os objetos carro em suas respectivas lista de acordo com a categoria do mesmo
		ArrayList carrosCompactos = new ArrayList<Carro>();
		carrosCompactos.add(chevrolet_corsa);
		
		ArrayList carrosSUV = new ArrayList<Carro>();
		carrosSUV.add(fiat_freemont);
		
		ArrayList carrosEsportivos = new ArrayList<Carro>();
		carrosEsportivos.add(lamborgini_miura);
		
		// criando um cliente 
		Cliente cli = new Cliente();
		
		// criando os objetos locadora de acorodo com as categorias de veículos
		Locadora southCar = new Locadora("SouthCar", 210f, 200f , TipoCarro.COMPACTO, carrosCompactos);
		Locadora westCar = new Locadora("WestCar", 530f, 200f, TipoCarro.ESPORTIVO, carrosEsportivos);
		Locadora northCar = new Locadora("NorthCar", 630f, 600f, TipoCarro.SUV, carrosSUV);		
		Locadora locadoraSelecionada = new Locadora();	
		
		// abrindo um arquivo texto localizado na raiz do projeto
		FileReader leitor = new FileReader("arquivo.txt");		
		BufferedReader lerArq = new BufferedReader(leitor);
		// armazenando o arquivo texto em uma string 
		String scan = lerArq.readLine().toString().toUpperCase();	
		
		// separando a string com marcadores : e armazenando em um array de string
		String[] splitScan = scan.split(":");
		
		cli.setEntrada(sdf.parse(splitScan[3])); // Data de entrada
		cli.setSaida(sdf.parse(splitScan[4])); // Data de saída
		
		for(int i=0; i< splitScan.length;i++){
			
			if(splitScan[i].equals("PREMIUM")){
				
				cli.setPremium(true);
				
				southCar.setTaxaDiasUteis(150f);
				southCar.setTaxafimDeSemana(90f);
				
				westCar.setTaxaDiasUteis(150f);
				westCar.setTaxafimDeSemana(90f);
			
				
				northCar.setTaxaDiasUteis(580f);
				northCar.setTaxafimDeSemana(590f);
				
				for(int j=0; j< splitScan.length;j++){
					
					if(splitScan[j].equals("1") || splitScan[j].equals("2")){	
						
						if(splitScan[1].equals("ESPORTIVO")){
							locadoraSelecionada = westCar;
							
						}else if(splitScan[j].equals("1")||splitScan[j].equals("2")||splitScan[j].equals("3") ||splitScan[j].equals("4")){
							
							if(splitScan[1].equals("COMPACTO")){
								locadoraSelecionada = southCar;		
							}
							
							else if(splitScan[j].equals("5") || splitScan[j].equals("6") || splitScan[j].equals("7")){
								locadoraSelecionada = northCar;
										
							}
						}
					}
					
				}
			}else{
				
				cli.setPremium(false);
				
				for(int j=0; j< splitScan.length;j++){	
					
					if(splitScan[j].equals("1") || splitScan[j].equals("2")){	
						
						if(splitScan[1].equals("ESPORTIVO")){
							locadoraSelecionada = westCar;
							
						}else if(splitScan[j].equals("1")||splitScan[j].equals("2")||splitScan[j].equals("3") ||splitScan[j].equals("4")){
							
							if(splitScan[1].equals("COMPACTO")){
								locadoraSelecionada = southCar;		
							}
							
							else if(splitScan[j].equals("5") || splitScan[j].equals("6") || splitScan[j].equals("7")){
								locadoraSelecionada = northCar;
										
							}
						}
					}
				}
				
			}			
			
		}
		
		locadoraSelecionada.retornaDadosLocadora();
	}

}