package locadora;

import java.util.ArrayList;
import java.util.List;

public class Locadora {
	
	private String nome;	
	private Float taxaDiasUteis;
	private Float taxafimDeSemana;
	private TipoCarro tipoCarro;
	private ArrayList<Carro> carros;	

	public Locadora(String nome, Float taxaDiasUteis, Float taxafimDeSemana, TipoCarro tipoCarro, ArrayList<Carro> carros) {
		super();
		this.nome = nome;
		this.taxaDiasUteis = taxaDiasUteis;
		this.taxafimDeSemana = taxafimDeSemana;
		this.tipoCarro = tipoCarro;
		this.carros = carros;
	}

	public Locadora() {
		
	}

	public ArrayList<Carro> getCarros() {
		return carros;
	}

	public void setCarros(ArrayList<Carro> carros) {
		this.carros = carros;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Float getTaxaDiasUteis() {
		return taxaDiasUteis;
	}

	public void setTaxaDiasUteis(Float taxaDiasUteis) {
		this.taxaDiasUteis = taxaDiasUteis;
	}

	public Float getTaxafimDeSemana() {
		return taxafimDeSemana;
	}

	public void setTaxafimDeSemana(Float taxafimDeSemana) {
		this.taxafimDeSemana = taxafimDeSemana;
	}

	public TipoCarro getTipoCarro() {
		return tipoCarro;
	}

	public void setTipoCarro(TipoCarro tipoCarro) {
		this.tipoCarro = tipoCarro;
	}
	

	public void retornaDadosLocadora(){
		System.out.println(this.getCarros().get(0).getModelo() +" : "+this.getNome());
	}
	

		

}
